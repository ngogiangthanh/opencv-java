Language data for fonts:
arial, courier new, times new roman, verdana
vni-aptima, vni-book, vni-helve, vni-palatin, vni-tekon, vni-times, vni-univer
.vntime, .vnarial

Installation:
Copy (override, if necessary) vie.* files into tesseract's tessdata folder.