Tesseract 3.02 Vietnamese language data for fonts:
arial, courier new, tahoma, times new roman, verdana
vni-aptima, vni-book, vni-helve, vni-oxford, vni-palatin, vni-tekon, vni-times, vni-univer, vni-zap
.vntime, .vnarial

Installation:
Copy vie-1.traineddata file into tesseract's tessdata folder.